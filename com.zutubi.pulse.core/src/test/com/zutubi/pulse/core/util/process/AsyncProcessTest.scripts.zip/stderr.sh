#! /bin/bash

echo line 1 1>&2
echo line 2 1>&2
echo line 3 1>&2
exit 0

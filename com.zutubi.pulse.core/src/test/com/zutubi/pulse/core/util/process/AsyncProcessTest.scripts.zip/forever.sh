#! /bin/bash

while true
do
    sleep 1
    echo yes
done


#! /bin/bash

echo line 1
echo line 2
echo line 3
exit 0
